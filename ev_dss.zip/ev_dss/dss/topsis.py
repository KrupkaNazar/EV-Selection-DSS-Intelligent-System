import numpy as np
import pandas as pd

def topsis_score(df: pd.DataFrame, cols: dict, weights: dict, minimize: set) -> pd.Series:
    """
    Обчислює TOPSIS-бал (0..1).
    
    ✅ Підтримка min/max критеріїв
    ✅ Повне нормування
    ✅ Збереження нормованої матриці критеріїв для Explainability:
        df.attrs["component_scores"]
    """

    crit_keys = [k for k in weights.keys() if cols.get(k) in df.columns]

    if not crit_keys:
        df.attrs["component_scores"] = None
        return pd.Series(0.0, index=df.index)

    norm_df = pd.DataFrame(index=df.index)

    for k in crit_keys:
        col = cols[k]
        s = pd.to_numeric(df[col], errors="coerce")

        med = s.median()
        s = s.fillna(med)

        mn, mx = s.min(), s.max()
        if mx > mn:
            v = (s - mn) / (mx - mn)
        else:
            v = pd.Series(0.5, index=s.index)

        if k in minimize:
            v = 1.0 - v

        norm_df[k] = v

    X = norm_df.values.astype(float)  # n × m
    norm_vec = np.sqrt((X ** 2).sum(axis=0))
    R = X / np.where(norm_vec == 0, 1, norm_vec)

    w = np.array([weights[k] for k in crit_keys], dtype=float)
    w = w / (w.sum() if w.sum() > 0 else 1.0)

    V = R * w 

    ideal_best  = V.max(axis=0)
    ideal_worst = V.min(axis=0)

    d_pos = np.sqrt(((V - ideal_best)  ** 2).sum(axis=1))
    d_neg = np.sqrt(((V - ideal_worst) ** 2).sum(axis=1))
    c = d_neg / np.where((d_pos + d_neg) == 0, 1, (d_pos + d_neg))
    score = pd.Series(c, index=df.index)

    df_norm_for_explain = norm_df.copy()

    df_norm_for_explain = df_norm_for_explain.reindex(columns=weights.keys(), fill_value=0)

    df.attrs["component_scores"] = df_norm_for_explain

    return score
