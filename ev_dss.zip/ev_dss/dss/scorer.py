import pandas as pd
import numpy as np


def _norm(series: pd.Series, invert: bool = False) -> pd.Series:
    """
    Устійке нормування 0..1:
    - автоматична заміна пропусків на медіану
    - захист від нульового діапазону
    - optional invert: показники "менше-краще"
    """
    s = pd.to_numeric(series, errors="coerce")

    if s.isna().any():
        med = s.median(skipna=True)
        s = s.fillna(med if np.isfinite(med) else 0)

    mn, mx = s.min(), s.max()
    if not np.isfinite(mn) or not np.isfinite(mx) or mn == mx:
        base = pd.Series(0.5, index=s.index)
        return (1 - base) if invert else base

    score = (s - mn) / (mx - mn)

    if invert:
        score = 1.0 - score

    return score.clip(0.0, 1.0)

def score_df(
    df: pd.DataFrame,
    cols: dict,
    weights: dict,
    body_pref: list = None,
    prefer_fastcharge_kw: float = None,
):
    """
    Розраховує лінійний інтегральний бал fit_score з пояснюваністю.
    Повертає DataFrame + додає стовпець 'fit_score'.
    """

    comp = {}

    if cols.get("price") and weights.get("price", 0) > 0:
        norm_price = _norm(df[cols["price"]], invert=True)
        comp["price"] = weights["price"] * norm_price

    if cols.get("range_km") and weights.get("range_km", 0) > 0:
        norm_range = _norm(df[cols["range_km"]])
        comp["range_km"] = weights["range_km"] * norm_range

    if cols.get("fastcharge_kw") and weights.get("fastcharge_kw", 0) > 0:
        raw = pd.to_numeric(df[cols["fastcharge_kw"]], errors="coerce")
        base = _norm(raw)

        if prefer_fastcharge_kw is not None:
            bonus = ((raw >= prefer_fastcharge_kw).fillna(False).astype(float)) * 0.1
            base = (base + bonus).clip(0, 1)

        comp["fastcharge_kw"] = weights["fastcharge_kw"] * base

    if cols.get("eff_whkm") and weights.get("eff_whkm", 0) > 0:
        norm_eff = _norm(df[cols["eff_whkm"]], invert=True)
        comp["eff_whkm"] = weights["eff_whkm"] * norm_eff

    if cols.get("accel_0_100") and weights.get("accel_0_100", 0) > 0:
        norm_acc = _norm(df[cols["accel_0_100"]], invert=True)
        comp["accel_0_100"] = weights["accel_0_100"] * norm_acc

    if cols.get("body") and weights.get("body_fit", 0) > 0 and body_pref:
        bodies = df[cols["body"]].astype(str).str.lower()
        match = bodies.apply(
            lambda x: any(pref.lower() in x for pref in body_pref)
        ).astype(float)
        comp["body_fit"] = weights["body_fit"] * match

    comp_df = pd.DataFrame(comp)

    df_out = df.copy()
    df_out["fit_score"] = comp_df.sum(axis=1)

    df_out.attrs["component_scores"] = comp_df

    return df_out
