import re

ALIASES = {
    "model": [
        "model", "name", "vehicle", "car", "trim", "variant", "edition"
    ],
    "brand": [
        "brand", "make", "manufacturer", "company"
    ],

    "price": [
        "price", "price_eur", "price_usd", "msrp", "cost", "market_price",
        "base_price", "starting_price", "sale_price"
    ],

    "range_km": [
        "range_km", "range", "wltp_range_km", "range_wltp_km",
        "electric_range_km", "epa_range_km", "cltc_range_km"
    ],

    "battery_kwh": [
        "battery_kwh", "battery_capacity_kwh", "battery", "accumulator_kwh",
        "usable_battery_kwh", "total_battery_kwh", "net_battery_kwh"
    ],

    "eff_whkm": [
        "efficiency_wh_km", "consumption_wh_km", "wh_km",
        "energy_consumption_wh_km", "consumption",
        "energy_consumption_kwh_100km",
        "efficiency_wh_per_km"
    ],

    "fastcharge_kw": [
        "fastcharge_kw", "dc_fast_kw", "peak_dc_kw", "max_dc_kw",
        "dc_charging_power_kw", "fast_charge_power", "dc_fast_charge",
        "fast_charging_power_kw_dc"
    ],

    "accel_0_100": [
        "accel_0_100", "acceleration_0_100_s", "accel_s",
        "zero_to_hundred_s", "acceleration", "0_100_kmh"
    ],

    "body": [
        "body", "body_type", "car_body", "vehicle_class", "car_body_type"
    ],

    "segment": [
        "segment", "vehicle_segment", "class", "market_segment",
        "car_segment", "car_class", "category"
    ],

    "drive": [
        "drive", "drivetrain", "awd_fwd_rwd", "drive_type",
        "drivetrain_type", "powertrain"
    ],

    "seats": [
        "seats", "num_seats", "passengers", "seating_capacity"
    ],

    "length_mm": [
        "length_mm", "length", "vehicle_length_mm", "overall_length_mm"
    ],
    "width_mm": [
        "width_mm", "width", "overall_width_mm"
    ],
    "height_mm": [
        "height_mm", "height", "overall_height_mm"
    ],

    "weight_kg": [
        "weight_kg", "curb_weight_kg", "mass_kg", "vehicle_weight",
        "kerb_weight", "gross_weight_kg"
    ],

    "cargo_volume_l": [
        "cargo_volume_l", "trunk_volume_l", "boot_volume_l"
    ],
    "towing_capacity_kg": [
        "towing_capacity_kg", "towing_kg", "tow_limit_kg"
    ],
    "top_speed_kmh": [
        "top_speed_kmh", "vmax_kmh", "max_speed_kmh"
    ],
}

def normalize_column_name(c: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", c.strip().lower()).strip("_")


def find_column(df, aliases):
    candidates = []

    for alias in aliases:
        alias_norm = normalize_column_name(alias)

        if alias_norm in df.columns:
            return alias_norm

        for col in df.columns:
            if col == alias_norm:
                candidates.append((0, col))
            elif col.startswith(alias_norm):
                candidates.append((1, col))
            elif alias_norm in col:
                candidates.append((2, col))

    if candidates:
        candidates.sort(key=lambda x: x[0])
        return candidates[0][1]

    return None
