from pathlib import Path
import pandas as pd
import numpy as np
from .aliases import ALIASES, normalize_column_name, find_column


def load_dataset(path: str):
    """
    Завантажує CSV, нормалізує назви колонок, визначає ключові параметри
    та повертає:
        ✅ DataFrame
        ✅ словник відповідностей основних колонок

    Додатково:
    - Автоматично перетворює числові поля
    - Попереджає про відсутні критично важливі колонки
    """

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Dataset not found: {p}")

    try:
        df = pd.read_csv(p)
    except Exception as e:
        raise ValueError(f"Не вдалося прочитати CSV: {e}")

    df = df.rename(columns={c: normalize_column_name(c) for c in df.columns})

    cols = {k: find_column(df, v) for k, v in ALIASES.items()}

    numeric_cols = [
        "price", "range_km", "battery_kwh", "eff_whkm",
        "fastcharge_kw", "accel_0_100", "seats",
        "length_mm", "weight_kg"
    ]

    for k in numeric_cols:
        c = cols.get(k)
        if c:
            df[c] = (
                df[c]
                .astype(str)
                .str.replace(",", ".", regex=False)  # 1,23 → 1.23
                .str.replace(" ", "", regex=False)   # 1 000 → 1000
            )
            df[c] = pd.to_numeric(df[c], errors="coerce")

    REQUIRED = ["brand", "model", "price", "range_km"]
    missing = [k for k in REQUIRED if cols.get(k) is None]

    if missing:
        print("⚠️ УВАГА: У датасеті відсутні критично важливі колонки:", missing)

    return df, cols
