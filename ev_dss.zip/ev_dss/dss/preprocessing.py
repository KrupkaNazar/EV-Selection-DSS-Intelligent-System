import pandas as pd
import numpy as np

def normalize_body(value: str):
    if not isinstance(value, str):
        return None

    v = value.strip().lower()

    v = v.replace("-", " ").replace("/", " ").replace("_", " ")

    mapping = {
        "hatchback": ["hatch", "hatchback"],
        "sedan": ["sedan", "saloon", "liftback"],
        "wagon": ["wagon", "estate", "station"],
        "crossover": ["crossover"],
        "suv": ["suv", "sport utility", "sport activity", "crossover suv"],
        "mpv": ["mpv", "minivan", "multi purpose"],
        "van": ["van", "cargo van"],
        "pickup": ["pickup", "pick up", "ute"],
        "coupe": ["coupe"],
        "convertible": ["convertible", "roadster", "cabrio"],
    }

    for norm, keys in mapping.items():
        if any(k in v for k in keys):
            return norm

    return None


def normalize_drive(value: str):
    if not isinstance(value, str):
        return None

    v = value.lower()

    if "awd" in v or "4wd" in v:
        return "awd"
    if "fwd" in v:
        return "fwd"
    if "rwd" in v:
        return "rwd"

    return None

def apply_filters(
    df: pd.DataFrame,
    cols: dict,
    budget_min: float = None,
    budget_max: float = None,
    min_range_km: float = None,
    bodies: list = None,
    seats_min: int = None,
    drive: str = None,
    length_max_mm: float = None,
    weight_max_kg: float = None,
    min_battery_kwh: float = None,
):

    df = df.copy()

    if cols.get("body"):
        df[cols["body"]] = (
            df[cols["body"]]
            .astype(str)
            .apply(normalize_body)
        )

    if cols.get("drive"):
        df[cols["drive"]] = (
            df[cols["drive"]]
            .astype(str)
            .apply(normalize_drive)
        )

    mask = pd.Series(True, index=df.index)

    if cols.get("price") and (budget_min is not None or budget_max is not None):
        low = float(budget_min) if budget_min is not None else float("-inf")
        high = float(budget_max) if budget_max is not None else float("inf")
        mask &= df[cols["price"]].between(low, high, inclusive="both")

    if cols.get("range_km") and min_range_km is not None:
        mask &= df[cols["range_km"]] >= float(min_range_km)

    if cols.get("body") and bodies:
        mask &= df[cols["body"]].isin(bodies)

    if cols.get("seats") and seats_min is not None:
        mask &= pd.to_numeric(df[cols["seats"]], errors="coerce") >= int(seats_min)

    if cols.get("drive") and drive:
        mask &= df[cols["drive"]] == drive

    if cols.get("length_mm") and length_max_mm is not None:
        mask &= pd.to_numeric(df[cols["length_mm"]], errors="coerce") <= float(length_max_mm)

    if cols.get("weight_kg") and weight_max_kg is not None:
        mask &= pd.to_numeric(df[cols["weight_kg"]], errors="coerce") <= float(weight_max_kg)

    if cols.get("battery_kwh") and min_battery_kwh is not None:
        mask &= pd.to_numeric(df[cols["battery_kwh"]], errors="coerce") >= float(min_battery_kwh)

    return df[mask].copy()
