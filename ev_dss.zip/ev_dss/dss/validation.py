import pandas as pd

NUMERIC_MUST_BE_NONNEG = [
    "price", "range_km", "battery_kwh", "fastcharge_kw",
    "eff_whkm", "accel_0_100", "seats", "length_mm", "weight_kg"
]

def profile_dataframe(df: pd.DataFrame, cols: dict) -> dict:
    """Легка діагностика для розділу 3.2: пропуски, типи, базові діапазони."""
    report = {"shape": df.shape, "missing": {}, "negatives": {}, "ranges": {}}
    for k in NUMERIC_MUST_BE_NONNEG:
        c = cols.get(k)
        if not c or c not in df.columns:
            continue
        s = pd.to_numeric(df[c], errors="coerce")
        report["missing"][k]   = int(s.isna().sum())
        report["negatives"][k] = int((s < 0).sum())
        if s.notna().any():
            report["ranges"][k] = (float(s.min()), float(s.max()))
    return report

def assert_minimal_quality(df: pd.DataFrame, cols: dict) -> None:
    """Мінімальні перевірки — падаємо рано, якщо щось критичне відсутнє."""
    required = ["brand", "model", "price", "range_km"]
    missing  = [r for r in required if not cols.get(r)]
    if missing:
        raise ValueError(f"Відсутні критично важливі стовпці: {missing}")
