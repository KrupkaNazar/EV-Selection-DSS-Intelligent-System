import pandas as pd
from .preprocessing import apply_filters
from .scorer import score_df
from .topsis import topsis_score


DEFAULT_WEIGHTS = {
    "price": 0.35,
    "range_km": 0.30,
    "fastcharge_kw": 0.15,
    "eff_whkm": 0.10,
    "accel_0_100": 0.05,
    "body_fit": 0.05,
}


def recommend(
    df: pd.DataFrame,
    cols: dict,
    filters: dict,
    weights: dict = None,
    topk: int = 20,
    method: str = "linear",
    diversify_by_brand: bool = True,
):
    """
    Основна DSS-функція.
    """

    if weights is None:
        weights = DEFAULT_WEIGHTS.copy()

    filtered = apply_filters(
        df, cols,
        budget_min=filters.get("budget_min"),
        budget_max=filters.get("budget_max"),
        min_range_km=filters.get("min_range_km"),
        bodies=None,
        seats_min=filters.get("seats_min"),
        drive=None,
        length_max_mm=filters.get("length_max_mm"),
        weight_max_kg=filters.get("weight_max_kg"),
        min_battery_kwh=filters.get("min_battery_kwh"),
    )

    body_col = cols.get("body")
    body_pref = filters.get("bodies")

    if body_col and body_pref:
        pref = [b.lower() for b in body_pref]
        filtered = filtered[
            filtered[body_col].astype(str).str.lower().isin(pref)
        ]

    drive_col = cols.get("drive")
    drive_pref = filters.get("drive")

    if drive_col and drive_pref:
        d = drive_pref.lower()
        filtered = filtered[
            filtered[drive_col].astype(str).str.lower().eq(d)
        ]

    if filtered.empty:
        return filtered.copy()

    if method == "topsis":

        minimize = {"price", "eff_whkm", "accel_0_100"}

        scores = topsis_score(filtered, cols, weights, minimize)

        scored = filtered.copy()
        scored["fit_score"] = scores

        scored.attrs["component_scores"] = filtered.attrs.get("component_scores")

    else:
        scored = score_df(
            filtered, cols, weights,
            body_pref=filters.get("bodies"),
            prefer_fastcharge_kw=filters.get("prefer_fastcharge_kw"),
        )

    sort_cols = ["fit_score"]
    ascending = [False]

    price_col = cols.get("price")
    if price_col:
        sort_cols.append(price_col)
        ascending.append(True)

    ranked = scored.sort_values(sort_cols, ascending=ascending)

    if not diversify_by_brand or not cols.get("brand"):
        return ranked.head(topk)

    N = 2
    brands = ranked[cols["brand"]].astype(str)

    result_idx = []
    brand_counts = {}

    for idx, brand in brands.items():
        count = brand_counts.get(brand, 0)
        if count < N:
            result_idx.append(idx)
            brand_counts[brand] = count + 1
        if len(result_idx) >= topk:
            break

    return ranked.loc[result_idx]
