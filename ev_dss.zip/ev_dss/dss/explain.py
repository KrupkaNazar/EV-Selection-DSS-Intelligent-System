import pandas as pd
import streamlit as st
import plotly.graph_objects as go

CRITERIA_LABELS = {
    "price": "Ціна",
    "range_km": "Запас ходу",
    "fastcharge_kw": "Швидка DC-зарядка",
    "eff_whkm": "Енергоефективність",
    "accel_0_100": "Розгін 0–100 км/год",
    "body_fit": "Відповідність типу кузова",
}

CRITERIA_EXPLANATION = {
    "price": "нижча вартість підвищує загальну привабливість моделі",
    "range_km": "великий запас ходу підвищує практичність авто у щоденному та міжміському використанні",
    "fastcharge_kw": "вища потужність DC-зарядки зменшує час поповнення енергії",
    "eff_whkm": "менше споживання енергії означає економічнішу експлуатацію",
    "accel_0_100": "швидший розгін покращує динаміку та комфорт при обгонах",
    "body_fit": "модель відповідає вибраному типу кузова",
}

def explain_linear(row: pd.Series, cols: dict, comp_scores: pd.DataFrame, weights: dict):
    contrib = {}
    if comp_scores is None or not isinstance(comp_scores, pd.DataFrame):
        return {"contrib": {}, "total": 0.0}

    for k, w in weights.items():
        if k not in comp_scores.columns:
            continue
        val = float(comp_scores.loc[row.name, k])
        contrib[k] = val * w

    return {"contrib": contrib, "total": sum(contrib.values())}

def explain_topsis(row: pd.Series, cols: dict, weights: dict, norm_df: pd.DataFrame):
    contrib = {}
    if norm_df is None or not isinstance(norm_df, pd.DataFrame):
        return {"contrib": {}, "total": 0.0}

    for k, w in weights.items():
        if k not in norm_df.columns:
            continue
        val = float(norm_df.loc[row.name, k])
        contrib[k] = val * w

    return {"contrib": contrib, "total": sum(contrib.values())}

def pretty_reason(row: pd.Series, cols: dict, explanation: dict) -> str:
    brand = row.get(cols.get("brand"), "")
    model = row.get(cols.get("model"), "")
    price = row.get(cols.get("price"), None)

    price_str = ""
    if price is not None:
        try:
            price_str = f" ({float(price)/1000:.1f}k$)"
        except:
            pass

    c = explanation.get("contrib", {})
    if not c:
        return f"{brand} {model}{price_str}: дані для пояснення відсутні."

    header = f"### 📝 Деталізація внеску критеріїв для **{brand} {model}{price_str}**\n"

    lines = []
    for k, v in sorted(c.items(), key=lambda kv: kv[1], reverse=True):
        label = CRITERIA_LABELS.get(k, k)
        text = CRITERIA_EXPLANATION.get(k, "критерій вплинув на оцінку")
        contrib = f"{v:.3f}"

        if v > 0.08:
            color = "🟢 **(сильний вплив)**"
        elif v > 0.03:
            color = "🟡 **(середній вплив)**"
        else:
            color = "⚪ **(слабкий вплив)**"

        lines.append(f"{color} — **{label}:** +{contrib} — {text}")

    block_list = "\n\n".join(lines)

    top_factor = max(c, key=c.get)
    top_label = CRITERIA_LABELS.get(top_factor, top_factor)

    paragraph = f"""
### 📌 Узагальнений висновок
Модель **{brand} {model}{price_str}** отримала підвищений рейтинг завдяки ключовому фактору —  
**{top_label}**, який мав найбільший позитивний внесок.

Також значний вплив мали:  
**{", ".join([CRITERIA_LABELS.get(k, k) for k in sorted(c, key=c.get, reverse=True)[1:3]])}**.

Автомобіль демонструє збалансоване поєднання характеристик  
та є сильним конкурентом у межах вимог клієнта.
"""

    chart_df = pd.DataFrame({
        "Критерій": [CRITERIA_LABELS.get(k, k) for k in c.keys()],
        "Внесок": list(c.values())
    }).sort_values("Внесок", ascending=True)

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=chart_df["Внесок"],
        y=chart_df["Критерій"],
        orientation="h",
        marker=dict(color="#1976D2")
    ))

    fig.update_layout(
        height=380,
        width=800,
        title="Візуалізація внеску критеріїв",
        margin=dict(l=140, r=40, t=60, b=40),
        xaxis=dict(title="Внесок", fixedrange=True),
        yaxis=dict(title="Критерій", fixedrange=True),
    )

    st.plotly_chart(
        fig,
        width="stretch",
        config={
            "scrollZoom": False,
            "doubleClick": False,
            "displayLogo": False,
            "modeBarButtonsToRemove": [
                "zoom", "zoomIn", "zoomOut", "autoScale", "pan",
                "select2d", "lasso2d", "zoom2d", "resetScale2d",
            ],
        }
    )

    return header + block_list + "\n\n" + paragraph
