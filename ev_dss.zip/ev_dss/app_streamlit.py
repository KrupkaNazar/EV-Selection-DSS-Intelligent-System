import streamlit as st
import pandas as pd
import tempfile

from dss.loader import load_dataset
from dss.recommender import recommend, DEFAULT_WEIGHTS
from dss.explain import explain_linear, explain_topsis, pretty_reason


st.set_page_config(page_title="DSS підбору електромобілів", layout="wide")

st.markdown("""
<style>
[data-testid="stSidebar"] {
    width: 380px !important;
}
section[data-testid="stSidebar"] > div {
    width: 380px !important;
}

input[type=number] {
    -moz-appearance: textfield;
}
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
</style>

<script>
document.addEventListener('wheel', function(e){
  const el = document.activeElement;
  if (!el) return;
  const tag = el.tagName.toLowerCase();
  const type = (el.getAttribute('type') || '').toLowerCase();
  if (tag === 'input' && (type === 'number' || type === 'range')) {
      el.blur();
  }
}, { passive: true });
</script>
""", unsafe_allow_html=True)

st.title("Інтелектуальна DSS-система підбору електромобілів для клієнтів автосалону")

st.markdown("""
Система допомагає підібрати оптимальні електромобілі за бюджетом, 
технічними характеристиками, типом кузова, швидкістю зарядки та іншими параметрами.  
Методи оцінювання: **Linear (WSM)** та **TOPSIS**.
""")

# ============================
# Переклади кузовів і приводу
# ============================

BODY_TRANSLATE = {
    "hatchback": "хетчбек",
    "sedan": "седан",
    "wagon": "універсал",
    "crossover": "кросовер",
    "suv": "SUV/позашляховик",
    "mpv": "мінівен (MPV)",
    "van": "вантажопасажирський VAN",
    "pickup": "пікап",
    "coupe": "купе",
    "convertible": "кабріолет",
}
BODY_REVERSE = {v: k for k, v in BODY_TRANSLATE.items()}

DRIVE_TRANSLATE = {
    "awd": "повний привід (AWD)",
    "fwd": "передній привід (FWD)",
    "rwd": "задній привід (RWD)",
}
DRIVE_REVERSE = {v: k for k, v in DRIVE_TRANSLATE.items()}

# ============================
# Завантаження даних
# ============================

st.sidebar.header("1) Дані")

uploaded = st.sidebar.file_uploader(
    "Завантажте CSV з характеристиками електромобілів",
    type=["csv"]
)

default_path = "electric_vehicles_spec_2025.csv"
path = default_path

if uploaded is not None:
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".csv")
    tmp.write(uploaded.getbuffer())
    tmp.close()
    path = tmp.name

df, cols = load_dataset(path)

with st.expander("Переглянути завантажені дані"):
    st.dataframe(df.head(20), width="stretch")

# ============================
# Фільтри
# ============================

st.sidebar.header("2) Фільтри")

budget = st.sidebar.slider("Бюджет ($)", 0, 200000, (20000, 60000), 1000)
min_range = st.sidebar.slider("Мінімальний WLTP запас ходу (км)", 0, 1200, 300, 10)

bodies_ui = st.sidebar.multiselect(
    "Бажані типи кузова:",
    list(BODY_TRANSLATE.values()),
    default=[BODY_TRANSLATE["crossover"], BODY_TRANSLATE["suv"]]
)
bodies = [BODY_REVERSE[b] for b in bodies_ui]

prefer_dc = st.sidebar.slider("Мінімальна потужність DC-зарядки (кВт)", 0, 400, 120, 10)
seats_min = st.sidebar.number_input("Мінімальна кількість місць", 0, 9, 0)

drive_ui = st.sidebar.selectbox(
    "Тип приводу:",
    ["будь-який"] + list(DRIVE_TRANSLATE.values())
)
drive = DRIVE_REVERSE.get(drive_ui)

min_batt = st.sidebar.number_input("Мінімальна ємність батареї (кВт·год)", 0, 200, 0)
max_length = st.sidebar.number_input("Максимальна довжина (мм)", 0, 6000, 0)
max_weight = st.sidebar.number_input("Максимальна маса (кг)", 0, 4500, 0)

filters = dict(
    budget_min=budget[0],
    budget_max=budget[1],
    min_range_km=min_range,
    bodies=bodies,
    prefer_fastcharge_kw=prefer_dc,
    seats_min=seats_min,
    drive=drive,
    min_battery_kwh=min_batt,
    length_max_mm=max_length if max_length > 0 else None,
    weight_max_kg=max_weight if max_weight > 0 else None,
)

# ============================
# Ваги критеріїв
# ============================

st.sidebar.header("3) Ваги критеріїв")

weights = DEFAULT_WEIGHTS.copy()
for k, label in [
    ("price","Ціна (менше — краще)"),
    ("range_km","Запас ходу"),
    ("fastcharge_kw","Швидка DC-зарядка"),
    ("eff_whkm","Енергоефективність (менше — краще)"),
    ("accel_0_100","Розгін 0–100 км/год (менше — краще)"),
    ("body_fit","Відповідність типу кузова"),
]:
    weights[k] = st.sidebar.slider(label, 0.0, 1.0, float(weights[k]), 0.01)

s = sum(weights.values())
if s > 0:
    weights = {k: v / s for k, v in weights.items()}

# ============================
# Метод оцінювання
# ============================

st.sidebar.header("4) Метод оцінювання")
method = st.sidebar.selectbox("Оберіть метод:", ["linear", "topsis"])

# ============================
# Результати
# ============================

st.header("Рекомендовані моделі")

topk = st.number_input("Кількість моделей (Top-K):", 5, 50, 20)

result = recommend(
    df, cols, filters,
    weights=weights,
    topk=int(topk),
    method=method,
    diversify_by_brand=True
)

# Якщо немає результатів — послабити фільтри
if len(result) == 0:
    st.info("""
### Моделей не знайдено за вказаними фільтрами  
Показуємо **найбільш схожі варіанти** з автоматичним послабленням умов:
- без обмеження по кузову  
- без обмеження по приводу  
- запас ходу знижено на 20%  
- бюджет розширено на ±20%
""")

    relaxed = dict(filters)
    relaxed["bodies"] = None
    relaxed["drive"] = None

    if relaxed.get("min_range_km"):
        relaxed["min_range_km"] = max(0, int(relaxed["min_range_km"] * 0.8))

    span = filters["budget_max"] - filters["budget_min"]
    relaxed["budget_min"] = max(0, int(filters["budget_min"] - span * 0.2))
    relaxed["budget_max"] = int(filters["budget_max"] + span * 0.2)

    result = recommend(
        df, cols, relaxed,
        weights=weights,
        topk=int(topk),
        method=method,
        diversify_by_brand=True
    )

# Таблиця
pretty = result.copy()
pretty_cols = {}

if cols.get("brand"):
    pretty_cols[cols["brand"]] = "Виробник"

if cols.get("model"):
    pretty_cols[cols["model"]] = "Модель"

if cols.get("price"):
    pretty_cols[cols["price"]] = "Ціна ($)"

if cols.get("range_km"):
    pretty_cols[cols["range_km"]] = "Запас ходу (км)"

if cols.get("fastcharge_kw"):
    pretty_cols[cols["fastcharge_kw"]] = "DC-зарядка (кВт)"

if cols.get("eff_whkm"):
    pretty_cols[cols["eff_whkm"]] = "Wh/км"

if cols.get("accel_0_100"):
    pretty_cols[cols["accel_0_100"]] = "0–100 (с)"

pretty_cols["fit_score"] = "Індекс відповідності"

pretty = pretty.rename(columns={k: v for k, v in pretty_cols.items() if k in pretty.columns})

st.dataframe(pretty.reset_index(drop=True), width="stretch")

csv = pretty.to_csv(index=False).encode("utf-8")
st.download_button("Завантажити результати (CSV)", csv, "ev_recommendations.csv")

# ============================
# Пояснення моделі
# ============================

if len(result) > 0:

    st.subheader("Пояснення прийнятого рішення")

    comp = result.attrs.get("component_scores")

    if len(result) == 1:
        explain_idx = 1
    else:
        explain_idx = st.number_input(
            "Оберіть номер моделі (1 — перший рядок):",
            min_value=1,
            max_value=len(result),
            value=1,
            step=1
        )

    row = result.iloc[int(explain_idx) - 1]

    # ----- WSM -----
    if method == "linear":
        exp = explain_linear(row, cols, comp, weights)
        st.markdown("### Деталізація внеску критеріїв")
        st.markdown(pretty_reason(row, cols, exp))

    # ----- TOPSIS (новий формат, як WSM) -----
    elif method == "topsis":
        exp = explain_topsis(row, cols, weights, comp)
        st.markdown("### Деталізація внеску критеріїв")
        st.markdown(pretty_reason(row, cols, exp))

# ============================
# Методика
# ============================

with st.expander("Методика"):
    st.markdown("""
### **Лінійна модель (WSM)**
Σ (вага × нормалізоване значення критерію)

### **TOPSIS**
- нормування  
- ідеальна та анти-ідеальна точка  
- знаходження відстані до еталонів  

### **Диверсифікація брендів**
Не більше **2 моделей одного бренду**.
""")
